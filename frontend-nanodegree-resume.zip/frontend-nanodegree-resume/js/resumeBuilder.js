/*
This is empty on purpose! Your code to build the resume will go here.
 */

 //YOU MUST WRITE THIS OR ELSE THE COMPUTER WILL NOT RECOGNIZE THE $. IT WILL THINK IT HASN'T BEEN DEFINED.
/*global $ */


//Below is an object declaration for my bio

var bio = {
    "name": "Alianza Clyne",
    "role": "Front-End Web Developer & Cyber Security Analyst",
    "contacts": { //another object
        "mobile": "678-724-6316",
        "email": "Email: octavia1011@gmail.com",
        "github": "octavia1011",
        "location": "McDonough, GA"
    },
    "welcomeMessage": "Welcome to my resume!",
    //"biopic": img.src ='https://image.ibb.co/iC7CTw/my_photo.png'
    "biopic": 'images/my_photo.png',
    "skills": ["HTML", "CSS", "JavaScript", "Bootstrap"]  //array
};

bio.display = function() {
    var formattedName = HTMLheaderName.replace("%data%", bio.name);
    var formattedRole = HTMLheaderRole.replace("%data%", bio.role);

    $("#header").prepend(formattedRole);
    $("#header").prepend(formattedName);

    var formattedMobile = HTMLmobile.replace("%data%", bio.contacts.mobile);
    var formattedEmail = HTMLemail.replace("%data%", bio.contacts.email);
    var formattedGithub= HTMLgithub.replace("%data%",bio.contacts.github);
    var formattedLocation = HTMLlocation.replace("%data%", bio.contacts.location);
    $("#topContacts").append(formattedMobile + formattedEmail + formattedGithub + formattedLocation);
    $("#footerContacts").append(formattedMobile + formattedEmail + formattedGithub + formattedLocation);
    var formattedPic = HTMLbioPic.replace("%data%", bio.biopic); +
    $("#header").append(formattedPic);
    var formattedMsg = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
    $("#header").append(formattedMsg);
    $("#header").append(HTMLskillsStart);

    for (var i = 0; i < bio.skills.length; i++) {
        $("#skills").append(HTMLskills.replace("%data%", bio.skills[i]));
    }
};
bio.display();

//The data in this object is in a JSON format.
var work = {
    "jobs": [ //this creates an array
        { //object 1
            "employer": "Teens Transforming Technology",
            "title": "Instructor & Curriculum Developer",
            "location": "Remote",
            "dates": "August 2017 - present",
            "description": "Serves as a virtual receptionist for a variety of businesses ranging from law firms to subscription box companies"
        },
        { //object 2
            "employer": "Smith.ai",
            "title": "Virtual Receptionist",
            "location": "Remote",
            "dates": "March 2017 - present",
            "description": "Serves as a virtual receptionist for a variety of businesses ranging from law firms to subscription box companies"
        }
    ]
};

//1. THIS is how you would write a  for-in loop that goes over all jobs in work object

    //for (job in work.jobs) { //This says for EACH job in the work object and specifically the jobs array, do the following:
        //$("#workExperience").append(HTMLworkStart);

        //var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[job].employer); //This allows you to format each job's employer using HTMLworkEmployer
        /*
        var formattedEmployer: Creates a variable for the formatted employer
        HTMLworkEmployer.replace("%data%", work.jobs[job].employer): This means you're trying to replace %data% in HTMLworkEmployer with work.jobs[job].employer.
        work.jobs[job].employer: "Work"  shows that this is the object work. ".Jobs" says that you're  selecting the jobs array in the object work.
        [Job] says that you're selecting the job index (each of the jobs in the job awway) Job is first called in the for in loop called for (job in work.jobs){}
        ".employer": This states that you're specifically selecting  the "employer" property (or technically key) in each job array.
        */

       //var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[job].title);
        //var formattedEmployerTitle = formattedEmployer + formattedTitle; //Allows you to concatenate the employer and title for each job and save it to a new variable.
        //$(".work-entry: last").append(formattedEmployerTitle);
    //}

//This is used  to display work experience.
work.display = function() { //Display i a property that is added to the work object. It is set equal to a function. This is encapsulation because we are holding the display function inside the projects object.
    $("#workExperience").append(HTMLworkStart);

    for (var job = 0; job < work.jobs.length; job++) {
        //Note: Look back at the for in loop for work experience that was commented out. Almost everything  applies here except [job] is replaced with [job]
        var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[job].employer);
        var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[job].title);
        var formattedDates = HTMLworkDates.replace("%data%", work.jobs[job].dates);
        var formattedLocation = HTMLworkLocation.replace("%data%", work.jobs[job].location);
        var formattedDescription = HTMLworkDescription.replace("%data%", work.jobs[job].description);
        $(".work-entry:last").append(formattedEmployer); //This appends the last  element in work
        $(".work-entry:last").append(formattedTitle);
        $(".work-entry:last").append(formattedDates);
        $(".work-entry:last").append(formattedLocation);
        $(".work-entry:last").append(formattedDescription);
    }
};
work.display(); //This calls the function in work.display


//The data in this object is in a JSON format.
var projects = {
    "projects": [ //this creates an array
        { //object 1
            "title": "Portfolio Site",
            "dates": "August 2017",
            "description": "Created an online portfolio of projects as part of Udacity's Front-End Web Developer Nanodegree.",
            "images": ["images/portfolio-website.jpg"] //this is an array
        },
        { //object 2
            "title": "Animal Trading Card",
            "dates": "July 2017",
            "description": "Created an animal trading card using HTML and CSS as part of Udacity's Front-End Web Developer Nanodegree.",
            "images": ["images/animal-trading-card-pic.jpg"] //this is an array
        }
    ]
};

//This is used  to display projects.
projects.display = function() { //Display i a property that is added to the work object. It is set equal to a function. This is encapsulation because we are holding the display function inside the projects object.

    for (var project = 0; project < projects.projects.length; project++) {
        $("#projects").append(HTMLprojectStart); //HTMLprojectStart creates a new project entry
        var formattedTitle = HTMLprojectTitle.replace("%data%", projects.projects[project].title);
        var formattedDates = HTMLprojectDates.replace("%data%", projects.projects[project].dates);
        var formattedDescription = HTMLprojectDescription.replace("%data%", projects.projects[project].description);
        //var formattedImages = HTMLprojectImage.replace("%data%", projects.projects[project].images);
        $(".project-entry:last").append(formattedTitle); //This appends the last  element in work
        $(".project-entry:last").append(formattedDates);
        $(".project-entry:last").append(formattedDescription);
        //$(".project-entry:last").append(formattedImages);

        for (var image = 0; image < projects.projects[project].images.length; image++) {
           $(".project-entry:last").append(HTMLprojectImage.replace("%data%", projects.projects[project].images[image]));
       }
    }
};
projects.display(); //This calls the function in project.display


//The data in this object is in a JSON format.
var education = {
    "schools": [ //this creates an array
        { //object 1
            "name": "Clayton State University",
            "location": "Morrow, GA",
            "degree": "Dual Enrollment Student",
            "degreeDates": "January 2016 - May 2017",
            "majors": ["General Studies"], //this is an array
            //"url": "http://www.clayton.edu/"
        },
        { //object 2
            "name": "Georgia Connections Academy",
            "location": "Duluth, GA",
            "degree": "High School Student",
            "degreeDates": "August 2013 - May 2017",
            "majors": ["General Studies"], //this is an array
            //"url": "http://www.georgiaconnectionsacademy.edu/"
        }
    ],  //Put a comma here because you have two arrays in this object. The second awway is below.

    "onlineCourses": [ //this creates an array
        { //object 1
            "title": "Front-End Web Developer Nanodegree",
            "school": "Udacity",
            "dates": "June 2017 - present",
            "url": "https://www.udacity.com/course/front-end-web-developer-nanodegree--nd001"
        }
    ]
};

//This is used  to display education.
education.display = function() {
    $("#education").append(HTMLschoolStart);

    for (var school = 0; school < education.schools.length; school++) {

        var formattedSchoolName = HTMLschoolName.replace("%data%", education.schools[school].name);
        var formattedSchoolDegree= HTMLschoolDegree.replace("%data%", education.schools[school].degree);
        var formattedSchoolDates = HTMLschoolDates.replace("%data%", education.schools[school].degreeDates);
        var formattedSchoolLocation = HTMLschoolLocation.replace("%data%", education.schools[school].location);
        var formattedSchoolMajor = HTMLschoolMajor.replace("%data%", education.schools[school].majors);
        $(".education-entry:last").append(formattedSchoolName); //This appends the last  element in work
        $(".education-entry:last").append(formattedSchoolDegree);
        $(".education-entry:last").append(formattedSchoolDates);
        $(".education-entry:last").append(formattedSchoolLocation);
        $(".education-entry:last").append(formattedSchoolMajor);
    }

    for (var onlineCourse = 0; onlineCourse < education.onlineCourses.length; onlineCourse++) {
        $("#onlineCourses").append(HTMLonlineClasses);
        var formattedOnlineTitle = HTMLonlineTitle.replace("%data%", education.onlineCourses[onlineCourse].title);
        var formattedOnlineSchool = HTMLonlineSchool.replace("%data%", education.onlineCourses[onlineCourse].school);
        var formattedOnlineDates = HTMLonlineDates.replace("%data%", education.onlineCourses[onlineCourse].dates);
        var formattedOnlineURL = HTMLonlineURL.replace("%data%", education.onlineCourses[onlineCourse].url);
        $(".onlineCourses-entry:last").append(formattedOnlineTitle); //This appends the last  element in work
        $(".onlineCourses-entry:last").append(formattedOnlineSchool);
        $(".onlineCourses-entry:last").append(formattedOnlineDates);
        $(".onlineCourses-entry:last").append(formattedOnlineURL);
    };
};
education.display(); //This calls the function in education.display


//This grabs the click location on your site. "document" is really the website.
$(document).click(function(loc) {
  // your code goes here
  //Everytime the page is clicked, we create two new varaiables called x and  y.
  //Both x and y use the location event object from the click (ex: loc.pageX)
  //Then, we grab the pageX or pageY, which are the pixel values of the x and y locations of the clicks.
  var x = loc.pageX;
  var y = loc.pageY;
//Now rhat we have the x and y locattions, we can pass them into logClicks.
//Now our x and y locations will show up
  logClicks(x,y);
});

//This helps you to see the map
$("#mapDiv").append(googleMap);
